import React, {useEffect, useState, useCallback } from 'react';
import {Button,  Form, Input, Select, Row,List, Typography} from 'antd';
import 'antd/dist/antd.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const FormItem = Form.Item;
var data;
const StatementPage = ({profile}) => {

    const [statement, setStatement] = useState()
console.log(profile)

    const statements = async () =>  {
      const postdata = {
        "Table": " dbo.Statement INNER JOIN  dbo.idmsMst ON dbo.Statement.Client = dbo.idmsMst.Idx1 and dbo.Statement.userid = dbo.idmsMst.userid ",
        "Column": " TOP 100 PERCENT Left(idmsmst.Idx31,17) as CSD,dbo.Statement.Client, dbo.Statement.ProcDate, dbo.Statement.seq, dbo.Statement.details, dbo.Statement.type, dbo.Statement.ref,  dbo.Statement.IndNo, dbo.idmsMst.Idx2, dbo.idmsMst.Idx31, dbo.idmsMst.Idx13, dbo.idmsMst.Idx32, dbo.Statement.[month],  ISNULL(dbo.Statement.Debit, ' ') AS Debit, ISNULL(dbo.Statement.credit, ' ') AS Credit  ",
        "Where": " dbo.Statement.Userid = '"+ profile.code +"'  and dbo.Statement.client like '"+ profile.id +"'  ORDER BY dbo.Statement.Client, dbo.Statement.ProcDate desc, dbo.Statement.type ",
    
      };
      const myObjStr = JSON.stringify(postdata);
    //console.log(myObjStr)
      const API = await fetch(`http://localhost:3001/api/sql`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: myObjStr,
      }).catch(error => {
        console.error(error.headers);
      });
      let result = await API.json();
      // ClientType = result;
     data = result;
    //   const resd = result.map(item => {
    //    // ClientType.push(item.code);
    //      const  securityid  = item.securityid
    //   return { securityid }
    //  })
    setStatement(result)
    console.log(data)
    }


    useEffect(() => {
  
        statements()
      }, [])

    return (
        <>
                    <Row
        type="flex"
        justify="center"
        className="px-3 bg-white mh-page"
    >
             <table className="table table-striped">
             <tbody>
        <tr >
          <th  style={{textAlign:'left'}}>Date</th>
          <th  style={{textAlign:'left'}}>Reference</th>
          <th  style={{textAlign:'left'}}>Description</th>
          <th  style={{textAlign:'right'}}>Debit</th>
          <th  style={{textAlign:'right'}}>Credit</th>
        </tr>
       
     {data ?    
        data.map(link =>
          <tr>
            <td style={{textAlign:'left'}}>{link.ProcDate}</td>
            <td style={{textAlign:'left'}}>{link.ref}</td>
            <td style={{textAlign:'left'}}>{link.details}</td>
            <td style={{textAlign:'right'}}>{link.Debit}</td>
            <td style={{textAlign:'right'}}>{link.Credit}</td>
          </tr>

        )
      
      : null}
      
       </tbody>
    </table>
    </Row>
</>
   
   );
  };

  export default StatementPage;


