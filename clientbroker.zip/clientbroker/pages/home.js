import React from 'react';

const IndexPage = () => {
    return <h3>Index Page</h3>;
  };

  export default IndexPage;

