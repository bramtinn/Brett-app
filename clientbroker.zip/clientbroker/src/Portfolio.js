import React, {useEffect, useState, useCallback } from 'react';
import {Button,  Form, Input, Select, Row,List, Typography} from 'antd';
import 'antd/dist/antd.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const FormItem = Form.Item;
var data;
const PortfolioPage = ({profile}) => {

    const [statement, setStatement] = useState()


    const portfolio = async () =>  {
      const postdata = {
        "Table": " newport ",
        "Column": " *, ((NetAmount- Cost) / cost) * 100 as perc ",
        "Where": " idx6 = '"+ profile.id +"' and cost > '1' and idx4 > '0' order by idx1 ",
    
      };
      const myObjStr = JSON.stringify(postdata);
    //console.log(myObjStr)
      const API = await fetch(`http://localhost:3001/api/sql`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: myObjStr,
      }).catch(error => {
        console.error(error.headers);
      });
      let result = await API.json();
      // ClientType = result;
     data = result;
    //   const resd = result.map(item => {
    //    // ClientType.push(item.code);
    //      const  securityid  = item.securityid
    //   return { securityid }
    //  })
    setStatement(result)
    console.log(data)
    }


    useEffect(() => {
  
        portfolio()
      }, [])

    return (
        <>
                    <Row
        type="flex"
        justify="center"
        className="px-3 bg-white mh-page"
    >
             <table className="table table-striped">
             <tbody>
        <tr >
          <th  style={{textAlign:'left'}}>Security</th>
          <th  style={{textAlign:'left'}}>CSD</th>
          <th  style={{textAlign:'right'}}>No. of Shares</th>
          <th  style={{textAlign:'right'}}>Cost</th>
          <th  style={{textAlign:'right'}}>Current Value</th>
          <th  style={{textAlign:'right'}}>% profit/Loss</th>
        </tr>
       
     {data ?    
        data.map(link =>
          <tr>
            <td style={{textAlign:'left'}}>{link.Idx1}</td>
            <td style={{textAlign:'left'}}>{link.idx47}</td>
            <td style={{textAlign:'right'}}>{link.Idx4}</td>
            <td style={{textAlign:'right'}}>{link.Cost}</td>
            <td style={{textAlign:'right'}}>{link.NetAmount}</td>
            <td style={{textAlign:'right'}}>{link.perc}</td>
          </tr>

        )
      
      : null}
      
       </tbody>
    </table>
    </Row>
</>
   
   );
  };

  export default PortfolioPage;


