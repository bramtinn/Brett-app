import React from 'react';

const AboutPage = () => {
    return <h3>About Page</h3>;
  };

  export default AboutPage;

